pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "object",
  "additionalProperties": true,
  "required": [
    "supervisors"
  ],
  "properties": {
    "supervisors": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": true,
        "required": [
          "tabNum"
        ],
        "properties": {
          "tabNum": {
            "type": "string"
          },
          "lastName": {
            "type": "string"
          },
          "firstName": {
            "type": "string"
          },
          "middleName": {
            "type": "string"
          },
          "email": {
            "type": "string"
          }
        }
      }
    },
    "primes": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "privileges": {
      "type": "array",
      "items": {
        "type": "string"
      }
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});