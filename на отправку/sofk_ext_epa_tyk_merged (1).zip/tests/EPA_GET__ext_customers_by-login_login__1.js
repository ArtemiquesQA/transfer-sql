pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": true,
    "properties": {
      "mdm_id": {
        "type": "string"
      },
      "last_name": {
        "type": "string"
      },
      "first_name": {
        "type": "string"
      },
      "middle_name": {
        "type": "string"
      }
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});