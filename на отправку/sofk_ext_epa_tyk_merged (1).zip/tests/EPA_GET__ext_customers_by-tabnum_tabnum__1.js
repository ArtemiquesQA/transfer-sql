pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": true,
    "required": [
      "client_segment",
      "mdm_id",
      "role_in_team",
      "shifter"
    ],
    "properties": {
      "mdm_id": {
        "type": "string"
      },
      "last_name": {
        "type": "string"
      },
      "first_name": {
        "type": "string"
      },
      "middle_name": {
        "type": "string"
      },
      "client_segment": {
        "type": "string",
        "enum": [
          "UNKNOWN",
          "PRIME",
          "PRIVILEGE"
        ]
      },
      "role_in_team": {
        "type": "string",
        "enum": [
          "PERSONAL_MANAGER",
          "PFM",
          "PFM2",
          "BILL_ACCOUNTANT"
        ]
      },
      "shifter": {
        "type": "boolean"
      }
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});