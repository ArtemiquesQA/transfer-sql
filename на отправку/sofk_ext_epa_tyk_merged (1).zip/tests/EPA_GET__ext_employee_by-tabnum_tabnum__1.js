pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "object",
  "additionalProperties": true,
  "required": [
    "isSupervisor",
    "orgId",
    "roles"
  ],
  "properties": {
    "orgId": {
      "type": "string"
    },
    "lastName": {
      "type": "string"
    },
    "firstName": {
      "type": "string"
    },
    "middleName": {
      "type": "string"
    },
    "roles": {
      "type": "array",
      "items": {
        "type": "string",
        "enum": [
          "SUPERVISOR",
          "SUPERVISOR_PRIME",
          "PERSONAL_MANAGER",
          "PFM",
          "PFM2",
          "ACCOUNT_MANAGER",
          "ACCOUNT_MANAGER_PRIVILEGE"
        ]
      }
    },
    "isSupervisor": {
      "type": "boolean"
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});