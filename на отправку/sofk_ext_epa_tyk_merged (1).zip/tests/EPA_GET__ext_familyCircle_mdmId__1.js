pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": true,
    "required": [
      "mdmId"
    ],
    "properties": {
      "mdmId": {
        "type": "string"
      },
      "lastName": {
        "type": "string"
      },
      "firstName": {
        "type": "string"
      },
      "middleName": {
        "type": "string"
      },
      "birthDate": {
        "type": "string"
      },
      "relation": {
        "type": "string"
      }
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});