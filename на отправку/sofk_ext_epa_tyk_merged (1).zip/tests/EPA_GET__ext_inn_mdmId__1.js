pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": true,
    "required": [
      "inn"
    ],
    "properties": {
      "inn": {
        "type": "string"
      },
      "name": {
        "type": "string"
      },
      "clientPosition": {
        "type": "string"
      },
      "clientType": {
        "type": "string"
      },
      "hasSalaryProject": {
        "type": "boolean"
      },
      "isMain": {
        "type": "boolean"
      },
      "segment": {
        "type": "string"
      }
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});