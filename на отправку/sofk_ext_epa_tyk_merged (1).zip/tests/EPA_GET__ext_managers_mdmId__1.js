pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": true,
    "properties": {
      "employee": {
        "type": "object",
        "additionalProperties": true,
        "properties": {
          "last_name": {
            "type": "string"
          },
          "first_name": {
            "type": "string"
          },
          "middle_name": {
            "type": "string"
          },
          "login": {
            "type": "string"
          },
          "tabnum": {
            "type": "string"
          },
          "role_in_team": {
            "type": "string",
            "enum": [
              "SUPERVISOR",
              "SUPERVISOR_PRIME",
              "PERSONAL_MANAGER",
              "PFM",
              "PFM2",
              "BILL_ACCOUNTANT",
              "BROKER",
              "BILL_ACCOUNTANT_PRIVILEGE"
            ]
          },
          "remote_manager": {
            "type": "boolean"
          },
          "is_main": {
            "type": "boolean"
          },
          "email": {
            "type": "string"
          },
          "phone_num": {
            "type": "string"
          },
          "work_phone_num": {
            "type": "string"
          },
          "work_phone_ext": {
            "type": "string"
          },
          "workhours": {
            "type": "string"
          },
          "timezone": {
            "type": "string"
          },
          "target_date": {
            "type": "string"
          },
          "shift_date": {
            "type": "string"
          },
          "return_date": {
            "type": "string"
          }
        }
      },
      "client": {
        "type": "object",
        "additionalProperties": true,
        "properties": {
          "is_top": {
            "type": "boolean"
          },
          "is_vip": {
            "type": "boolean"
          },
          "service_group": {
            "type": "string"
          }
        }
      },
      "org": {
        "type": "object",
        "additionalProperties": true,
        "properties": {
          "address": {
            "type": "string"
          },
          "id": {
            "type": "string"
          },
          "name": {
            "type": "string"
          },
          "timezone": {
            "type": "string"
          },
          "workhours": {
            "type": "string"
          }
        }
      },
      "status": {
        "type": "object",
        "additionalProperties": true,
        "properties": {
          "id": {
            "type": "integer"
          },
          "name": {
            "type": "string"
          }
        }
      }
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});