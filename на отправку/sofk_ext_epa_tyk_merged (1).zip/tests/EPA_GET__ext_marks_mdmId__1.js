pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "object",
  "additionalProperties": true,
  "required": [
    "top",
    "vip",
    "supervip",
    "ExOb",
    "service_group",
    "service_group_name"
  ],
  "properties": {
    "top": {
      "type": "boolean"
    },
    "vip": {
      "type": "boolean"
    },
    "supervip": {
      "type": "boolean"
    },
    "ExOb": {
      "type": "boolean"
    },
    "service_group": {
      "type": "string"
    },
    "service_group_name": {
      "type": "string"
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});