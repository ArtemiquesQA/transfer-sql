pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": true,
    "properties": {
      "tabnum": {
        "type": "string"
      },
      "login": {
        "type": "string"
      },
      "last_name": {
        "type": "string"
      },
      "first_name": {
        "type": "string"
      },
      "middle_name": {
        "type": "string"
      },
      "email": {
        "type": "string"
      },
      "flag_main": {
        "type": "boolean"
      },
      "org_id": {
        "type": "string"
      },
      "org_name": {
        "type": "string"
      },
      "org_address": {
        "type": "string"
      },
      "org_workhours": {
        "type": "string"
      },
      "org_timezone": {
        "type": "string"
      },
      "status_id": {
        "type": "integer"
      },
      "status": {
        "type": "string"
      },
      "phone_num": {
        "type": "string"
      },
      "work_phone_num": {
        "type": "string"
      },
      "work_phone_ext": {
        "type": "string"
      },
      "workhours": {
        "type": "string"
      },
      "timezone": {
        "type": "string"
      },
      "remote_manager": {
        "type": "boolean"
      },
      "vip": {
        "type": "boolean"
      },
      "top": {
        "type": "boolean"
      }
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});