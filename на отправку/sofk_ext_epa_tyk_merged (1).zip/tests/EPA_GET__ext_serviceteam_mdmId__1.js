pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "object",
  "additionalProperties": true,
  "required": [
    "segment",
    "team"
  ],
  "properties": {
    "segment": {
      "type": "string",
      "enum": [
        "PRIME",
        "PRIVILEGE"
      ]
    },
    "team": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": true,
        "required": [
          "flag_main",
          "login",
          "orgId",
          "role",
          "status",
          "statusId",
          "tabNum"
        ],
        "properties": {
          "role": {
            "type": "string",
            "enum": [
              "SUPERVISOR",
              "SUPERVISOR_PRIME",
              "PERSONAL_MANAGER",
              "PFM",
              "PFM2",
              "ACCOUNT_MANAGER",
              "ACCOUNT_MANAGER_PRIVILEGE"
            ]
          },
          "flag_main": {
            "type": "boolean"
          },
          "tabNum": {
            "type": "string"
          },
          "login": {
            "type": "string"
          },
          "lastName": {
            "type": "string"
          },
          "firstName": {
            "type": "string"
          },
          "middleName": {
            "type": "string"
          },
          "email": {
            "type": "string"
          },
          "phoneNum": {
            "type": "string"
          },
          "workPhoneNum": {
            "type": "string"
          },
          "workPhoneExt": {
            "type": "string"
          },
          "orgId": {
            "type": "string"
          },
          "orgName": {
            "type": "string"
          },
          "orgAddress": {
            "type": "string"
          },
          "statusId": {
            "type": "integer"
          },
          "status": {
            "type": "string"
          }
        }
      }
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});