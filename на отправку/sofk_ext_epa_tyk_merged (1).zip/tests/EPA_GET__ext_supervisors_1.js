pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "object",
  "additionalProperties": true,
  "required": [
    "list",
    "total"
  ],
  "properties": {
    "list": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": true,
        "required": [
          "departmentHierarchy",
          "first_name",
          "last_name",
          "login",
          "middle_name",
          "org_address",
          "org_id",
          "org_name",
          "org_timezone",
          "org_workhours",
          "tabnum"
        ],
        "properties": {
          "tabnum": {
            "type": "string"
          },
          "login": {
            "type": "string"
          },
          "last_name": {
            "type": "string"
          },
          "first_name": {
            "type": "string"
          },
          "middle_name": {
            "type": "string"
          },
          "email": {
            "type": "string"
          },
          "departmentHierarchy": {
            "type": "array",
            "items": {
              "type": "string"
            }
          },
          "org_id": {
            "type": "string"
          },
          "org_name": {
            "type": "string"
          },
          "org_address": {
            "type": "string"
          },
          "org_workhours": {
            "type": "string"
          },
          "org_timezone": {
            "type": "string"
          },
          "phone_num": {
            "type": "string"
          },
          "work_phone_num": {
            "type": "string"
          },
          "work_phone_ext": {
            "type": "string"
          },
          "roles": {
            "type": "array",
            "items": {
              "type": "string",
              "enum": [
                "SUPERVISOR",
                "SUPERVISOR_PRIME",
                "PERSONAL_MANAGER",
                "PFM",
                "PFM2",
                "ACCOUNT_MANAGER",
                "ACCOUNT_MANAGER_PRIVILEGE"
              ]
            }
          }
        }
      }
    },
    "total": {
      "type": "integer"
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});