pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "object",
  "additionalProperties": true,
  "required": [
    "mdmId",
    "relativeName"
  ],
  "properties": {
    "mdmId": {
      "type": "string"
    },
    "lastName": {
      "type": "string"
    },
    "firstName": {
      "type": "string"
    },
    "middleName": {
      "type": "string"
    },
    "birthDate": {
      "type": "string"
    },
    "relativeName": {
      "type": "string"
    },
    "specificRelation": {
      "type": "string"
    },
    "isApproved": {
      "type": "boolean"
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});