pm.test("HTTP status 201", function () {
    pm.response.to.have.status(201);
});

const schema = {
  "type": "object",
  "additionalProperties": true,
  "required": [
    "customer",
    "serviceTeam"
  ],
  "properties": {
    "customer": {
      "type": "object",
      "additionalProperties": true,
      "properties": {
        "lastName": {
          "type": "string"
        },
        "firstName": {
          "type": "string"
        },
        "middleName": {
          "type": "string"
        },
        "branchExtCode": {
          "type": "string"
        }
      }
    },
    "serviceTeam": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": true,
        "required": [
          "firstName",
          "lastName",
          "role"
        ],
        "properties": {
          "role": {
            "type": "string",
            "enum": [
              "PERSONAL_MANAGER",
              "SUPERVISOR",
              "SUPERVISOR_PRIME",
              "PFM",
              "PFM2",
              "BILL_ACCOUNTANT",
              "BILL_ACCOUNTANT_PRIVILEGE"
            ]
          },
          "lastName": {
            "type": "string"
          },
          "firstName": {
            "type": "string"
          },
          "middleName": {
            "type": "string"
          }
        }
      }
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});