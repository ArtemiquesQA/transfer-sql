pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "object",
  "additionalProperties": true,
  "required": [
    "customer",
    "isExOb",
    "isSuperVip",
    "isTop",
    "isVip",
    "serviceGroup",
    "servicePack",
    "team"
  ],
  "properties": {
    "customer": {
      "type": "object",
      "additionalProperties": true,
      "properties": {
        "mdm_id": {
          "type": "string"
        },
        "last_name": {
          "type": "string"
        },
        "first_name": {
          "type": "string"
        },
        "middle_name": {
          "type": "string"
        }
      }
    },
    "servicePack": {
      "type": "object",
      "additionalProperties": true,
      "properties": {
        "name": {
          "type": "string"
        },
        "type": {
          "type": "string",
          "enum": [
            "UNKNOWN",
            "PRIME",
            "RETAIL",
            "PRIVILEGE"
          ]
        }
      }
    },
    "isVip": {
      "type": "boolean"
    },
    "isTop": {
      "type": "boolean"
    },
    "team": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": true,
        "required": [
          "role"
        ],
        "properties": {
          "role": {
            "type": "string",
            "enum": [
              "PERSONAL_MANAGER",
              "SUPERVISOR",
              "SUPERVISOR_PRIME",
              "PFM",
              "PFM2",
              "BILL_ACCOUNTANT",
              "BILL_ACCOUNTANT_PRIVILEGE"
            ]
          },
          "branch": {
            "type": "object",
            "additionalProperties": true,
            "properties": {
              "id": {
                "type": "integer"
              },
              "code": {
                "type": "string"
              },
              "name": {
                "type": "string"
              },
              "address": {
                "type": "string"
              },
              "types": {
                "type": "object",
                "additionalProperties": true,
                "properties": {
                  "present": {
                    "type": "boolean"
                  }
                }
              }
            }
          },
          "manager": {
            "type": "object",
            "additionalProperties": true,
            "required": [
              "firstName",
              "id",
              "lastName",
              "middleName"
            ],
            "properties": {
              "id": {
                "type": "integer"
              },
              "lastName": {
                "type": "string"
              },
              "firstName": {
                "type": "string"
              },
              "middleName": {
                "type": "string"
              },
              "phoneNum": {
                "type": "string"
              },
              "workPhoneNum": {
                "type": "string"
              },
              "workPhoneExt": {
                "type": "string"
              }
            }
          },
          "shift": {
            "type": "object",
            "additionalProperties": true,
            "required": [
              "manager"
            ],
            "properties": {
              "manager": {
                "type": "object",
                "additionalProperties": true,
                "required": [
                  "firstName",
                  "id",
                  "lastName",
                  "middleName"
                ],
                "properties": {
                  "id": {
                    "type": "integer"
                  },
                  "lastName": {
                    "type": "string"
                  },
                  "firstName": {
                    "type": "string"
                  },
                  "middleName": {
                    "type": "string"
                  },
                  "phoneNum": {
                    "type": "string"
                  },
                  "workPhoneNum": {
                    "type": "string"
                  },
                  "workPhoneExt": {
                    "type": "string"
                  }
                }
              },
              "shiftDateFrom": {
                "type": "string"
              },
              "shiftDateTo": {
                "type": "string"
              },
              "reason": {
                "type": "string"
              }
            }
          }
        }
      }
    },
    "serviceGroup": {
      "type": "object",
      "additionalProperties": true,
      "required": [
        "kind"
      ],
      "properties": {
        "id": {
          "type": "integer"
        },
        "kind": {
          "type": "string",
          "enum": [
            "UNASSIGNED",
            "PRIME",
            "AFFILIATE",
            "TEMPORARY_AGREEMENT",
            "TOP_AFFLUENT",
            "ELSE"
          ]
        }
      }
    },
    "tempAgreementExpirationDate": {
      "type": "string"
    },
    "isExOb": {
      "type": "boolean"
    },
    "isSuperVip": {
      "type": "boolean"
    },
    "company": {
      "type": "string"
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});