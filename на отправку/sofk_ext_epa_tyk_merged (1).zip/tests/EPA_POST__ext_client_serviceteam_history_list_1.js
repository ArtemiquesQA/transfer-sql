pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "object",
  "additionalProperties": true,
  "required": [
    "list"
  ],
  "properties": {
    "list": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": true,
        "required": [
          "comment",
          "datetime",
          "type"
        ],
        "properties": {
          "datetime": {
            "type": "string"
          },
          "type": {
            "type": "string"
          },
          "comment": {
            "type": "array",
            "items": {
              "type": "object",
              "additionalProperties": true,
              "required": [
                "name",
                "value"
              ],
              "properties": {
                "name": {
                  "type": "string"
                },
                "value": {
                  "type": "string"
                }
              }
            }
          },
          "requester": {
            "type": "object",
            "additionalProperties": true,
            "properties": {
              "employee": {
                "type": "object",
                "additionalProperties": true,
                "required": [
                  "firstName",
                  "id",
                  "lastName",
                  "middleName"
                ],
                "properties": {
                  "id": {
                    "type": "integer"
                  },
                  "lastName": {
                    "type": "string"
                  },
                  "firstName": {
                    "type": "string"
                  },
                  "middleName": {
                    "type": "string"
                  },
                  "phoneNum": {
                    "type": "string"
                  },
                  "workPhoneNum": {
                    "type": "string"
                  },
                  "workPhoneExt": {
                    "type": "string"
                  }
                }
              },
              "branch": {
                "type": "object",
                "additionalProperties": true,
                "properties": {
                  "id": {
                    "type": "integer"
                  },
                  "code": {
                    "type": "string"
                  },
                  "name": {
                    "type": "string"
                  },
                  "address": {
                    "type": "string"
                  },
                  "types": {
                    "type": "object",
                    "additionalProperties": true,
                    "properties": {
                      "present": {
                        "type": "boolean"
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    "aggregates": {
      "type": "object",
      "additionalProperties": true,
      "required": [
        "total"
      ],
      "properties": {
        "total": {
          "type": "integer"
        },
        "sortableFields": {
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});