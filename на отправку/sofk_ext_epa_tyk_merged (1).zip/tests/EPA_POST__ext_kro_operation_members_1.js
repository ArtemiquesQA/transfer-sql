pm.test("HTTP status 200", function () {
    pm.response.to.have.status(200);
});

const schema = {
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": true,
    "required": [
      "employee",
      "login"
    ],
    "properties": {
      "employee": {
        "type": "object",
        "additionalProperties": true,
        "properties": {
          "lastName": {
            "type": "string"
          },
          "firstName": {
            "type": "string"
          },
          "middleName": {
            "type": "string"
          }
        }
      },
      "login": {
        "type": "string"
      }
    }
  }
};

pm.test("JSON Schema: required fields and types from Swagger", function () {
    pm.response.to.have.jsonSchema(schema);
});